#include <iostream>
#include <fstream>
#include <string>
#include <getopt.h>
#include "schedulers.hpp"

int main(int argc, char **argv)
{
    bool v, q, f = false;
    int c = 0;
    char *s, *input_file_name = nullptr;
    std::string line;

    // Arg parsing
    while ((c = getopt(argc, argv, "vqfs:")) != -1)
    {
        switch (c)
        {
        case 'v':
            v = true;
            break;
        case 's':
            s = optarg;
            break;

        case 'q':
            q = true;
            break;

        case 'f':
            f = true;
            break;

        case '?':
            fprintf(stderr,
                    "usage: %s [dcs<size>]\n", argv[0]);
            return 1;
        }
    };

    // Grab input file name, random file name
    input_file_name = argv[optind];

    // Parse scheduler type
    SCHEDULER_TYPES scheduler_type = parse_scheduler_type(s);
    char *scheduler_unmangled_name = GET_SCHEDULER_NAME_FROM_ENUM(scheduler_type);

    std::ifstream input_file(input_file_name);
    int arrival_time, seek_pos = 0;
    std::vector<request_t *> requests;
    int request_num = 0;
    // Read in input from file -> Read in Num Process -> Make VMAs
    while (getline(input_file, line))
    {
        // Ignore line comments
        if (line.c_str()[0] != '#')
        {
            sscanf(line.c_str(), "%d %d", &arrival_time, &seek_pos);
            request_t *new_request = new request_t;
            new_request->arr_time = arrival_time;
            new_request->seek_pos = seek_pos;
            new_request->request_num = request_num;
            new_request->start_time = 0;
            new_request->end_time = 0;
            requests.push_back(new_request);
            request_num++;
        }
    }
    input_file.close();

    Scheduler *THE_SCHEDULER = build_scheduler(request_num, requests, scheduler_type, v, q, f);

    if (v)
    {
        printf("TRACE\n");
    }

    while (true)
    {
        // if a new I/O arrived at the system at this current time
        THE_SCHEDULER->get_next_request_time();

        // if an IO is active and completed at this time
        if (THE_SCHEDULER->get_status() == ACTIVE)
        {
            // Check if request is done
            // if so, compute relevant info and store in IO request for final summary
            // else, move the head by one unit in the direction its going (to simulate seek)
            THE_SCHEDULER->evaluate_request_done();
        }
        // STATUS can be mutated in IF above, hence not using ELSE
        // if no IO request active now
        if (THE_SCHEDULER->get_status() == INACTIVE)
        {
            // if requests are pending
            if (THE_SCHEDULER->get_queue_size())
            {
                // Fetch the next request from IO-queue and start the new IO.
                THE_SCHEDULER->work_on_next_request();
            }
            // else if all IO from input file processed
            else
            {
                // exit simulation
                if (THE_SCHEDULER->all_requests_done())
                {
                    break;
                }
            }
        }
        if (THE_SCHEDULER->get_status() == ACTIVE)
        {
            // Increment Scheduler Clock / disk position
            THE_SCHEDULER->inc_disk_pos();
            THE_SCHEDULER->inc_time_was_busy();
        }
        THE_SCHEDULER->inc_sched_clock_time();
    }

    THE_SCHEDULER->print_final_output();

    return 0;
}