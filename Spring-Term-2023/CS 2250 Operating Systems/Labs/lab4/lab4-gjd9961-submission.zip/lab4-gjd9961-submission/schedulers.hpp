#include <iostream>
#include <deque>
#include <vector>
#include <cmath>
#ifndef SCHEDULERS
#define SCHEDULERS

const int MAX_REQUESTS = 10000;

enum DISK_DIRECTION
{
    UP = 1,
    DOWN = -1,
};

enum SCHEDULER_STATUS
{
    INACTIVE,
    ACTIVE,
};

enum SCHEDULER_TYPES
{
    FIFO,
    SSTF,
    LOOK,
    CLOOK,
    FLOOK,
};

typedef struct request_t
{
    int request_num;
    int arr_time;
    int seek_pos;
    int start_time;
    int end_time;
} Request;

SCHEDULER_TYPES parse_scheduler_type(char *input_sched_type)
{
    switch (std::toupper(*input_sched_type))
    {
    case 'N':
        return FIFO;
    case 'S':
        return SSTF;
    case 'L':
        return LOOK;
    case 'C':
        return CLOOK;
    case 'F':
        return FLOOK;
    default:
        throw std::invalid_argument("Invalid Algorithm Argument, Options Are: F/R/C/E/A/W");
    };
}

// Helper function for debugging
char *GET_SCHEDULER_NAME_FROM_ENUM(int enum_code)
{
    static char *enum_name[] = {
        (char *)"FIFO",
        (char *)"SSTF",
        (char *)"LOOK",
        (char *)"CLOOK",
        (char *)"FLOOK"};
    return enum_name[enum_code];
}

// Custom Exception
class NotImplemented : public std::logic_error
{
public:
    NotImplemented() : std::logic_error("Function or class not yet implemented"){};
};

class Scheduler
{
public:
    Scheduler(int NUM_Requests_, std::vector<request_t *> &requests, SCHEDULER_TYPES sched_type_, bool v_, bool q_, bool f_)
    {
        NUM_REQUESTS = NUM_Requests_;
        request_table = requests;
        scheduler_type = sched_type_;
        v = v_;
        f = f_;
        q = q_;
    }

    void print_final_output()
    {
        int temp_end_time = 0;
        for (std::vector<request_t *>::iterator it = request_table.begin(); it != request_table.end(); ++it)
        {
            request_t *req = *it;
            printf("%5d: %5d %5d %5d\n", req->request_num, req->arr_time, req->start_time, req->end_time);

            // Increment turnaround time
            total_turnaround += (req->end_time - req->arr_time);
            int req_wait_time = (req->start_time - req->arr_time);
            total_wait_time += req_wait_time;

            // See if we have our max wait time
            if (req_wait_time > max_waittime)
            {
                max_waittime = req_wait_time;
            }

            // Total time = last request completion time
            if (req->end_time > temp_end_time)
            {
                temp_end_time = req->end_time;
            }
        }

        total_time = temp_end_time;
        // Update calculated stats, then output
        calculate_stats();

        printf("SUM: %d %d %.4lf %.2lf %.2lf %d\n", total_time, tot_movement, io_utilization,
               avg_turnaround, avg_waittime, max_waittime);
    }

    // Returns scheduler's clock time
    int get_sched_clock_time()
    {
        return SCHED_CLOCK;
    }

    // Increments the schedulers clock time by 1
    void inc_sched_clock_time()
    {
        SCHED_CLOCK++;
    }

    // Increments the schedulers head position by 1
    void inc_disk_pos()
    {
        tot_movement += 1;
        if (DIRECTION == UP)
        {
            HEAD_POS += 1;
        }
        else
        {
            HEAD_POS -= 1;
        }
    }

    void inc_time_was_busy()
    {
        time_io_was_busy++;
    }
    bool all_requests_done()
    {
        return (RTABLE_POS > NUM_REQUESTS - 1);
    }

    // Returns a boolen flag representing if a new request has been added to the queue
    bool get_next_request_time()
    {
        if (all_requests_done())
        {
            return false;
        }

        int arr_time = request_table[RTABLE_POS]->arr_time;
        if (arr_time == SCHED_CLOCK)
        {
            // We have a request, add it to the queue
            request_t *req = request_table[RTABLE_POS];
            if (v)
            {
                printf("%d:%6d add %d\n", SCHED_CLOCK, req->request_num, req->seek_pos);
            }
            add_to_io_q(req);
            RTABLE_POS++;
            return true;
        }

        return false;
    }

    // Check if the request should be set to finished
    bool evaluate_request_done()
    {
        if (HEAD_POS == active_req->seek_pos)
        {
            // Have to calibrate -1 for simulation logic
            active_req->end_time = SCHED_CLOCK;
            STATUS = INACTIVE;

            // Accounting
            int busy_time = active_req->end_time - active_req->arr_time;

            if (v)
            {
                printf("%d:%6d finish %d\n", SCHED_CLOCK, active_req->request_num, busy_time);
            }
            return true;
        }
        return false;
    }

    // Grabs next IO request from queue, sets status to active, and removes the now active
    // Request from the queue.
    void work_on_next_request()
    {
        // Get next request from queue
        active_req = get_from_q();

        if (v)
        {
            printf("%d:%6d issue %d %d\n", SCHED_CLOCK, active_req->request_num, active_req->seek_pos, HEAD_POS);
        }

        // Figure out seek direction
        if (active_req->seek_pos == HEAD_POS)
        {
            if (evaluate_request_done())
            {
                work_on_next_request();
            }
        }
        if (active_req->seek_pos > HEAD_POS)
        {
            DIRECTION = UP;
        }
        else
        {
            DIRECTION = DOWN;
        }
    }

    SCHEDULER_STATUS get_status()
    {
        return STATUS;
    }

    request_t *get_last_added_req()
    {
        return request_table[RTABLE_POS - 1];
    }

    virtual int get_queue_size()
    {
        return request_queue.size();
    }

protected:
    DISK_DIRECTION DIRECTION = UP;
    SCHEDULER_STATUS STATUS = INACTIVE;
    bool q, f, v = false;
    SCHEDULER_TYPES scheduler_type;
    int HEAD_POS = 0;
    std::deque<request_t *> request_queue;
    std::vector<request_t *> request_table;
    request_t *active_req;
    int NUM_REQUESTS = 0;
    int SCHED_CLOCK = 0;
    int RTABLE_POS = 0;

    /**
    Accounting Information
     * total_time:      total simulated time, i.e. until the last I/O request has completed.
     * tot_movement:    total number of tracks the head had to be moved
     * io_utilization:  ratio of time_io_was_busy / total_time
     * avg_turnaround:  average turnaround time per operation from time of submission to time of completion
     * avg_waittime:    average wait time per operation (time from submission to issue of IO request to start disk operation) maximum wait time for any IO operation.
     * max_waittime:     maximum wait time for any IO operation.
     */
    int total_time = 0;
    int tot_movement = 0;
    int max_waittime = 0;
    double avg_turnaround, avg_waittime, io_utilization = 0;
    double total_turnaround, total_wait_time, time_io_was_busy = 0;

    virtual void add_to_io_q(request_t *req)
    {
        request_queue.push_back(req);
    }

    virtual request_t *get_from_q()
    {
        // Optarg verbosity
        if (q)
        {
            printf("\tGet: (");
            std::deque<request_t *>::iterator it;

            for (it = request_queue.begin(); it != request_queue.end(); ++it)
            {
                request_t *temp = *it;
                printf("%d:%d ", temp->request_num, std::abs(temp->seek_pos - HEAD_POS));
            }
        }
        // Optarg verbosity
        if (q)
        {
            printf(") --> %d\n", active_req->request_num);
        }
        // Pop the first request off the queue, set status to active
        request_t *temp = request_queue.front();
        request_queue.pop_front();
        // Update accounting
        update_status_and_started_time(temp);
        return temp;
    }

    void update_status_and_started_time(request_t *req)
    {
        STATUS = ACTIVE;
        req->start_time = SCHED_CLOCK;
    }
    void calculate_stats()
    {
        avg_turnaround = total_turnaround / (double)NUM_REQUESTS;
        avg_waittime = total_wait_time / (double)NUM_REQUESTS;
        io_utilization = time_io_was_busy / (double)total_time;
    }

    void flip_direction()
    {
        if (DIRECTION == UP)
        {
            DIRECTION = DOWN;
        }
        else
        {
            DIRECTION = UP;
        }
    }
};

class FIFO_Scheduler : Scheduler
{
public:
    FIFO_Scheduler(int NUM_Requests_, std::vector<request_t *> &requests, SCHEDULER_TYPES sched_type_, bool v_, bool q_, bool f_) : Scheduler(NUM_Requests_, requests, FIFO, v_, q_, f_){};

    virtual void add_to_io_q(request_t *req)
    {
        Scheduler::add_to_io_q(req);
    }

    virtual request_t *get_from_q()
    {
        return Scheduler::get_from_q();
    }

private:
};

class SSTF_Scheduler : Scheduler
{
public:
    SSTF_Scheduler(int NUM_Requests_, std::vector<request_t *> &requests, SCHEDULER_TYPES sched_type_, bool v_, bool q_, bool f_) : Scheduler(NUM_Requests_, requests, SSTF, v_, q_, f_){};

    virtual void add_to_io_q(request_t *req)
    {
        Scheduler::add_to_io_q(req);
    }

    virtual request_t *get_from_q()
    {
        std::deque<request_t *>::iterator it;
        std::deque<request_t *>::iterator closest_req_pos;
        request_t *closest_req = nullptr;
        int temp_closest_distance = 0;
        // Optarg verbosity
        if (q)
        {
            printf("\tGet: (");
        }

        for (it = request_queue.begin(); it != request_queue.end(); ++it)
        {
            request_t *candidate_req = *it;
            if (q)
            {
                printf("%d:%d ", candidate_req->request_num, std::abs(candidate_req->seek_pos - HEAD_POS));
            }

            if (!closest_req)
            {
                closest_req = candidate_req;
                temp_closest_distance = std::abs(closest_req->seek_pos - HEAD_POS);
                closest_req_pos = it;
            }
            else
            {
                int candidate_distance = std::abs(candidate_req->seek_pos - HEAD_POS);
                if (candidate_distance < temp_closest_distance)
                {
                    closest_req = candidate_req;
                    temp_closest_distance = candidate_distance;
                    closest_req_pos = it;
                }
            }
        }
        // Optarg verbosity
        if (q)
        {
            printf(") --> %d\n", closest_req->request_num);
        }
        // Pop closest req from q
        request_queue.erase(closest_req_pos);
        update_status_and_started_time(closest_req);
        return closest_req;
    }

private:
};

class LOOK_Scheduler : Scheduler
{
public:
    LOOK_Scheduler(int NUM_Requests_, std::vector<request_t *> &requests, SCHEDULER_TYPES sched_type_, bool v_, bool q_, bool f_) : Scheduler(NUM_Requests_, requests, LOOK, v_, q_, f_){};
    virtual void add_to_io_q(request_t *req)
    {
        Scheduler::add_to_io_q(req);
    }

    virtual request_t *get_from_q()
    {
        int closest_distance = -1;
        request_t *closest_req = nullptr;
        std::deque<request_t *>::iterator it, closest_it;
        if (q)
        {
            printf("\tGet: (");
        }
        for (it = request_queue.begin(); it != request_queue.end(); ++it)
        {
            request_t *candidate_req = *it;
            int candidate_distance = (candidate_req->seek_pos - HEAD_POS) * DIRECTION;

            if (candidate_distance >= 0)
            {
                // Verbose formatting
                if (q)
                {
                    printf("%d:%d ", candidate_req->request_num, candidate_distance);
                }
                if (!closest_req)
                {
                    closest_it = it;
                    closest_distance = candidate_distance;
                    closest_req = candidate_req;
                }
                if (candidate_distance < closest_distance)
                {
                    closest_it = it;
                    closest_distance = candidate_distance;
                    closest_req = candidate_req;
                }
            }
        }
        if (closest_distance < 0)
        {
            closest_req = nullptr;
            flip_direction();
            if (q)
            {
                printf(") --> change direction to %d\n\tGet: (", DIRECTION);
            }
            for (it = request_queue.begin(); it != request_queue.end(); ++it)
            {
                request_t *candidate_req = *it;
                int candidate_distance = (candidate_req->seek_pos - HEAD_POS) * DIRECTION;

                if (candidate_distance >= 0)
                {
                    // Verbose formatting
                    if (q)
                    {
                        printf("%d:%d ", candidate_req->request_num, candidate_distance);
                    }
                    if (!closest_req)
                    {
                        closest_it = it;
                        closest_distance = candidate_distance;
                        closest_req = candidate_req;
                    }
                    if (candidate_distance < closest_distance)
                    {
                        closest_it = it;
                        closest_distance = candidate_distance;
                        closest_req = candidate_req;
                    }
                }
            }
        }

        if (q)
        {
            printf(") --> %d dir=%d\n", closest_req->request_num, DIRECTION);
        }
        request_queue.erase(closest_it);
        update_status_and_started_time(closest_req);
        return closest_req;
    }
};

class CLOOK_Scheduler : Scheduler
{
public:
    CLOOK_Scheduler(int NUM_Requests_, std::vector<request_t *> &requests, SCHEDULER_TYPES sched_type_, bool v_, bool q_, bool f_) : Scheduler(NUM_Requests_, requests, CLOOK, v_, q_, f_){};
    virtual void add_to_io_q(request_t *req)
    {
        Scheduler::add_to_io_q(req);
    }

    virtual request_t *get_from_q()
    {
        std::deque<request_t *>::iterator it;
        std::deque<request_t *>::iterator closest_pos_req_position;
        std::deque<request_t *>::iterator smallest_min_req_position;
        request_t *closest_pos_req = nullptr;
        request_t *smallest_neg_req = nullptr;
        int temp_distance = 0;
        int temp_closest_pos_distance = 0;
        int temp_smallest_neg_distance = 0;

        if (q)
        {
            printf("\tGet: (");
        }
        // Search for smallest positive distance
        for (it = request_queue.begin(); it != request_queue.end(); ++it)
        {
            request_t *candidate_req = *it;
            temp_distance = candidate_req->seek_pos - HEAD_POS;
            if (q)
            {
                printf("%d:%d ", candidate_req->request_num, temp_distance);
            }
            if (temp_distance >= 0)
            {
                if (!closest_pos_req)
                {
                    closest_pos_req = candidate_req;
                    temp_closest_pos_distance = closest_pos_req->seek_pos - HEAD_POS;
                    closest_pos_req_position = it;
                }
                else
                {
                    if (temp_distance < temp_closest_pos_distance)
                    {
                        closest_pos_req = candidate_req;
                        temp_closest_pos_distance = temp_distance;
                        closest_pos_req_position = it;
                    }
                }
            }
            else
            {
                if (!smallest_neg_req)
                {
                    smallest_neg_req = candidate_req;
                    temp_smallest_neg_distance = smallest_neg_req->seek_pos - HEAD_POS;
                    smallest_min_req_position = it;
                }
                else
                {
                    if (temp_distance < temp_smallest_neg_distance)
                    {
                        smallest_neg_req = candidate_req;
                        temp_smallest_neg_distance = temp_distance;
                        smallest_min_req_position = it;
                    }
                }
            }
        }

        // If we have a positive distance, seek that direction (UP)
        if (closest_pos_req)
        {
            request_queue.erase(closest_pos_req_position);
            update_status_and_started_time(closest_pos_req);
            DIRECTION = UP;
            if (q)
            {
                printf(") --> %d\n", closest_pos_req->request_num);
            }
            return closest_pos_req;
        }
        else
        // Otherwise pretend we jump to 0 and seek min negative request position
        {
            request_queue.erase(smallest_min_req_position);
            update_status_and_started_time(smallest_neg_req);
            DIRECTION = DOWN;
            // Optarg verbosity
            if (q)
            {
                printf(") --> go to bottom and pick %d\n", smallest_neg_req->request_num);
            }
            return smallest_neg_req;
        }
    }
};

class FLOOK_Scheduler : Scheduler
{
public:
    FLOOK_Scheduler(int NUM_Requests_, std::vector<request_t *> &requests, SCHEDULER_TYPES sched_type_, bool v_, bool q_, bool f_) : Scheduler(NUM_Requests_, requests, FLOOK, v_, q_, f_){};
    virtual void add_to_io_q(request_t *req)
    {
        if (request_queue.size() == 0 && STATUS == INACTIVE)
        {
            request_queue.push_back(req);
            if (q)
            {
                printf("\tQ=0 ( %d:%d )\n", req->request_num, req->seek_pos);
            }
        }
        else
        {
            secondary_q.push_back(req);
            if (q)
            {
                printf("\tQ=1 ( ");
                std::deque<request_t *>::iterator it;
                for (it = secondary_q.begin(); it != secondary_q.end(); ++it)
                {
                    request_t *temp = *it;
                    printf("%d:%d ", temp->request_num, temp->seek_pos);
                }
                printf(")\n");
            }
        }
    }

    void print_q_triplets(std::deque<request_t *> *queue)
    {
        std::deque<request_t *>::iterator it;
        for (it = queue->begin(); it != queue->end(); ++it)
        {
            request_t *temp = *it;
            int distance = (temp->seek_pos - HEAD_POS) * DIRECTION;
            printf("%d:%d:%d", temp->request_num, temp->seek_pos, distance);
        }
    }

    virtual request_t *get_from_q()
    {
        int closest_distance = -1;
        request_t *closest_req = nullptr;
        std::deque<request_t *>::iterator it, closest_it;

        if (request_queue.size() == 0)
        {
            flip_qs();
        }
        if (q)
        {
            printf("AQ=%d dir=%d curtrack=%d:  Q[0] = ", qtype, DIRECTION, HEAD_POS);
            if (qtype == 0)
            {
                print_q_triplets(&request_queue);
                printf(")  Q[1] = ( ");
                print_q_triplets(&secondary_q);
                printf(")\n\tGet: (");
            }
            else
            {
                print_q_triplets(&secondary_q);
                printf(")  Q[1] = ( ");
                print_q_triplets(&request_queue);
                printf(")\n\tGet: (");
            }
        }
        for (it = request_queue.begin(); it != request_queue.end(); ++it)
        {
            request_t *candidate_req = *it;
            int candidate_distance = (candidate_req->seek_pos - HEAD_POS) * DIRECTION;

            if (candidate_distance >= 0)
            {
                // Verbose formatting
                if (q)
                {
                    printf("%d:%d ", candidate_req->request_num, candidate_distance);
                }
                if (!closest_req)
                {
                    closest_it = it;
                    closest_distance = candidate_distance;
                    closest_req = candidate_req;
                }
                if (candidate_distance < closest_distance)
                {
                    closest_it = it;
                    closest_distance = candidate_distance;
                    closest_req = candidate_req;
                }
            }
        }
        if (closest_distance < 0)
        {
            closest_req = nullptr;
            flip_direction();
            if (q)
            {
                printf(") --> change direction to %d\n\tGet: (", DIRECTION);
            }
            for (it = request_queue.begin(); it != request_queue.end(); ++it)
            {
                request_t *candidate_req = *it;
                int candidate_distance = (candidate_req->seek_pos - HEAD_POS) * DIRECTION;

                if (candidate_distance >= 0)
                {
                    // Verbose formatting
                    if (q)
                    {
                        printf("%d:%d ", candidate_req->request_num, candidate_distance);
                    }
                    if (!closest_req)
                    {
                        closest_it = it;
                        closest_distance = candidate_distance;
                        closest_req = candidate_req;
                    }
                    if (candidate_distance < closest_distance)
                    {
                        closest_it = it;
                        closest_distance = candidate_distance;
                        closest_req = candidate_req;
                    }
                }
            }
        }

        if (q)
        {
            printf(") --> %d dir=%d\n", closest_req->request_num, DIRECTION);
        }
        request_queue.erase(closest_it);
        update_status_and_started_time(closest_req);
        return closest_req;
    }
    virtual int get_queue_size()
    {
        return request_queue.size() + secondary_q.size();
    }

private:
    int qtype = 0;
    std::deque<request_t *>
        secondary_q;

    std::deque<request_t *> q_arr[2] = {request_queue, secondary_q};

    // Helper function to abstract the logic of swapping qs
    void flip_qs()
    {
        std::deque<request_t *> temp = request_queue;
        request_queue = secondary_q;
        secondary_q = temp;
        if (qtype == 0)
        {
            qtype = 1;
        }
        else
        {
            qtype = 0;
        }
    }
};

// Helper function to build pager based on CLI input
Scheduler *
build_scheduler(int NUM_Requests_, std::vector<request_t *> &requests, SCHEDULER_TYPES sched_type, bool v, bool q, bool f)
{
    switch (sched_type)
    {
    case FIFO:
        return (Scheduler *)new FIFO_Scheduler(NUM_Requests_, requests, sched_type, v, q, f);
    case SSTF:
        return (Scheduler *)new SSTF_Scheduler(NUM_Requests_, requests, sched_type, v, q, f);
    case LOOK:
        return (Scheduler *)new LOOK_Scheduler(NUM_Requests_, requests, sched_type, v, q, f);
    case CLOOK:
        return (Scheduler *)new CLOOK_Scheduler(NUM_Requests_, requests, sched_type, v, q, f);
    case FLOOK:
        return (Scheduler *)new FLOOK_Scheduler(NUM_Requests_, requests, sched_type, v, q, f);
    }
}

#endif