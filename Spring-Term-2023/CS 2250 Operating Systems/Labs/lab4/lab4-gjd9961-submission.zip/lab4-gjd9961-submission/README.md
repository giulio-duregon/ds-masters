# OS-Lab4 IO Scheduler - Giulio Duregon - gjd9961

## How to run `iosched`

**Short answer: run `make` from the CLI.**
My code uses the gcc compiler with the following flags:

```c++
CXX=g++
CXXFLAGS=-g -std=c++11 -Wall -pedantic -lstdc++
BIN=iosched
```

If running on linserv1, make sure to load in gcc version 9.2.0:

```bash
> module load gcc-9.2
> module unload gcc-4.8.5 # Unload the old version
```

To run `iosched`, simply call the executible with the input file you would like it to run on:

```bash
# How to run:
> ./iosched -s <scheduler type> -q -v -f #optional verbosity args
# Scheduler types: N, S, L, C, F
# i.e.
> ./iosched -s F -v -q
```

## Dependencies

`iosched.cpp` has 1 dependency: `schedulers.hpp`. Make sure to compile and link the object files to produce a correct executable.
